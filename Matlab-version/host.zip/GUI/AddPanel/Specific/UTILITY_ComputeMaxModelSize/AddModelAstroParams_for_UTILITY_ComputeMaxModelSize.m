function AddModelAstroParams_for_UTILITY_ComputeMaxModelSize()
%% Add astrocyte network parameters

    AddPanel('Model (Astro)');

    AddBoolScalar('enableAstro', false, 'Whether to enable the astrocyte network');
    
end
    