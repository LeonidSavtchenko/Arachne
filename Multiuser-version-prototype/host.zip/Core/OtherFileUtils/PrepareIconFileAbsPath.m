function iconPath = PrepareIconFileAbsPath(iconName)
%% Prepare icon file absolute path

    global HostDirTypes
    iconsDir = fullfile(GetDirPath(HostDirTypes.Code), 'assets');
    fileName = [iconName, '.png'];
    iconPath = fullfile(iconsDir, fileName);
    
end
