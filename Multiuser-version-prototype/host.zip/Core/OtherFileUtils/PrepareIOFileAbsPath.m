function filePathName = PrepareIOFileAbsPath(fileName)

    global HostDirTypes
    
    % Make sure that the input is not an absolute file path
    assert(~IsAbsPath(fileName));
    
    % A file name or a relative file path was passed
    hostIODirPath = GetDirPath(HostDirTypes.IO);
    filePathName = fullfile(hostIODirPath, fileName);
    
end
