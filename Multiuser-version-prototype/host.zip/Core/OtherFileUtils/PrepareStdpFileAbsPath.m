function absFilePath = PrepareStdpFileAbsPath(stdpFile)
%% Prepare tabulated STDP model file absolute path
%  (user can specify a file name, a relative file path or an absolute file path)

    if IsAbsPath(stdpFile)
        % Absolute file path was passed
        absFilePath = stdpFile;
    else
        % File name or relative file path was passed
        absFilePath = PrepareIOFileAbsPath(stdpFile);
    end
    
end