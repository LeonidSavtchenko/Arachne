function onOff = TrueFalseToOnOff(trueFalse)
%% !!?? Rename to "TrueFalse2OnOff"

    if trueFalse
        onOff = 'on';
    else
        onOff = 'off';
    end
end
