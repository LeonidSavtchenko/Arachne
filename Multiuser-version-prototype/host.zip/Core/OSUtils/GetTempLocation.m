function tempLocation = GetTempLocation()

    assert(ispc);
    
    tempLocation = getenv('TEMP');

end
