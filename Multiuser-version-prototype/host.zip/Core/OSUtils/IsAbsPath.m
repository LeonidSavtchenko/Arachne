function tf = IsAbsPath(path)
%% Determine if the path is absolute

    assert(ispc);
    tf = contains(path, ':');
    
end
