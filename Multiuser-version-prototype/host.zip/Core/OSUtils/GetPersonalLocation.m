function personalLocation = GetPersonalLocation()
%% Get user personal directory location

    assert(ispc);
    
    % Keep this logic consistent with the logic in Core\scripts\win-lin\params.bat
    personalLocation = winqueryreg(...
        'HKEY_CURRENT_USER', ...
        'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders', ...
        'Personal');
    
end
