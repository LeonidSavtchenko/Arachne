function maxLength = GetMaxFilePathNameLength()
%% Get the maximum allowed length of a file path (including the file name and extension)

    assert(ispc);
    maxLength = 260;
    
end
