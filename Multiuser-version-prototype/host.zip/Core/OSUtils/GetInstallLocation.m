function installLocation = GetInstallLocation()
%% Get Arachne install directory location
% !! Think about moving "scripts" an "3rdparty" folders to "OSUtils" folder

    assert(ispc);
    
    % Keep this logic consistent with the logic in Core\scripts\win-lin\params.bat
    installLocation = winqueryreg(...
        'HKEY_LOCAL_MACHINE', ...
        'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\Arachne', ...
        'InstallLocation');
    
end
