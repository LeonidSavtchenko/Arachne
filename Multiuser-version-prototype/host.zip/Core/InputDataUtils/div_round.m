function d = div_round(n, m)
%% Division and rounding to the nearest integer
    d = fix(n / m);
    rem = n - m * d;
    if m / 2 <= rem
        d = d + 1;
    end
end
