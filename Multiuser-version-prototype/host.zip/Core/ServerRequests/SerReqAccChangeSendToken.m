function success = SerReqAccChangeSendToken(newPassword)
%% !!

    url = PrepareAccOpURL('change/send-token');
    options = weboptions('MediaType', 'application/json');  % !! think about caching options
    data = struct('newPassword', newPassword);
    success = CallWebWriteWithErrorHandlingPolicy(url, data, options);
    
end
