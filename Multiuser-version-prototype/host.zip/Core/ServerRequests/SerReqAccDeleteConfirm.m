function success = SerReqAccDeleteConfirm(token)
%% !! Rename all these functions from SerReq to MgrReq? 

    url = PrepareAccOpURL('delete/confirm');
    options = weboptions('MediaType', 'application/json');  % !! think about caching options
    data = struct('token', token);
    success = CallWebWriteWithErrorHandlingPolicy(url, data, options);
    
end
