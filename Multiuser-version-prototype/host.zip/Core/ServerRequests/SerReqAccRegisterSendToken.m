function success = SerReqAccRegisterSendToken(login, password, email)
%% !!

    url = PrepareAccOpURL('register/send-token');
    options = weboptions('MediaType', 'application/json');  % !! think about caching options
    data = struct('login', login, 'password', password, 'email', email);
    success = CallWebWriteWithErrorHandlingPolicy(url, data, options);
    
end
