function url = PrepareAccOpURL(op)
% !! make sure we use https
% !! try to find some echo rest service for test

    global remoteHPC
    
    % !! move ServerRequests folder out of MainMenuGUI folder
    
    % !! move it to some consts?
    if remoteHPC
        urlPat = 'https://144.82.46.83/arachne/%s';
    else
        urlPat = 'http://localhost:8080/%s';
    end
    
    url = sprintf(urlPat, op);
    
    % !!
    url = 'http://httpbin.org/post';
    
end
