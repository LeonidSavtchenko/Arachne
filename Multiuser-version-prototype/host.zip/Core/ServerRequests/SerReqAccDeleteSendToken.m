function success = SerReqAccDeleteSendToken()
%% !!

    url = PrepareAccOpURL('delete/send-token');
    options = weboptions('MediaType', 'application/json');  % !! think about caching options
    data = struct();
    success = CallWebWriteWithErrorHandlingPolicy(url, data, options);
    
end
