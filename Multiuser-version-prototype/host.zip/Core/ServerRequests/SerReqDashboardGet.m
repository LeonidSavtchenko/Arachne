function [success, data] = SerReqDashboardGet()
%% !!

    global HostDirTypes
    
    url = PrepareAccOpURL('dashboard/get');
    data = struct();
    options = weboptions('MediaType', 'application/json');  % !! think about caching options
    % !! [success, data] = CallWebWriteWithErrorHandlingPolicy(url, data, options);

    success = true;
    
    % !! test
    hostCodeDirPath = GetDirPath(HostDirTypes.Code);
    fpath = fullfile(hostCodeDirPath, 'assets', 'test_dashboardGet.json');
    fid = fopen(fpath); 
    raw = fread(fid, inf); 
    str = char(raw'); 
    fclose(fid); 
    data = jsondecode(str);
    
end
