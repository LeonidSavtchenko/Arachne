function success = SerReqAccRecover(loginOrEmail)
%% !!

    url = PrepareAccOpURL('recover');
    options = weboptions('MediaType', 'application/json');  % !! think about caching options
    data = struct('loginOrEmail', loginOrEmail);
    success = CallWebWriteWithErrorHandlingPolicy(url, data, options);
    
end
