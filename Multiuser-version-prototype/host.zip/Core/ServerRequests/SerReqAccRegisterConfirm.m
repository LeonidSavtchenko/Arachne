function success = SerReqAccRegisterConfirm(token)
%% !!

    url = PrepareAccOpURL('register/confirm');
    options = weboptions('MediaType', 'application/json');  % !! think about caching options
    data = struct('token', token);
    success = CallWebWriteWithErrorHandlingPolicy(url, data, options);
    
end
