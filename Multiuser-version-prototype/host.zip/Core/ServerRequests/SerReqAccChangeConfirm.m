function success = SerReqAccChangeConfirm(token)
%% !!

    url = PrepareAccOpURL('change/confirm');
    options = weboptions('MediaType', 'application/json');  % !! think about caching options
    data = struct('token', token);
    success = CallWebWriteWithErrorHandlingPolicy(url, data, options);
    
end
