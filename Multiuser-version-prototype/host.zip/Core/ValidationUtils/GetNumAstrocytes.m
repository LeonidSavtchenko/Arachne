function num_a = GetNumAstrocytes(astro2PyraBinding, num_e, num_i)
%% Get the number of astrocytes

    global Astro2PyraBindings
    
    switch astro2PyraBinding
        case {Astro2PyraBindings.EE, Astro2PyraBindings.EI}
            num_a = num_e;
        case {Astro2PyraBindings.IE, Astro2PyraBindings.II}
            num_a = num_i;
        otherwise
            assert(false);  % Dev. assert
    end
    
end