function line = TranslateLocalVarDeclaration(line)
%% Replace "LOCAL varName" with "T varName"

    line = strrep(line, 'LOCAL', 'T');
    
    % TODO: Replace "LOCAL varName" with "T _lvarName" to be conformant with code in VERBATIM blocks
    %       (TranslateLineOfCode.m must be changed synchronously to add "_l" in front of local variable names)
    % line = regexprep(line, 'LOCAL(\s*)(\w)', 'T$1_l$2');
    
end
