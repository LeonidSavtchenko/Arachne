function dirPath = GetDirPath(dirType)
%% Get the absolute path to the host directory of the specified type

    global HostDirTypes
    global installedMode hostDirPaths
    
    if ~installedMode
        dirPath = cd;
        return
    end
    
    dirPath = hostDirPaths.(GetFieldName(HostDirTypes, dirType));
    
end
