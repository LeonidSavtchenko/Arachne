function RelParamsDispatcherCore()
%%

    global sclModel SclModels
    global w_ee_max w_ei_max w_ie_max w_ii_max
    global w_ee_max_bss w_ei_max_bss w_ie_max_bss w_ii_max_bss
    global w_ee_max_bsd w_ei_max_bsd w_ie_max_bsd w_ii_max_bsd
    
    switch sclModel
        case SclModels.BSS
            w_ee_max = w_ee_max_bss;
            w_ei_max = w_ei_max_bss;
            w_ie_max = w_ie_max_bss;
            w_ii_max = w_ii_max_bss;
        case SclModels.BSD
            w_ee_max = w_ee_max_bsd;
            w_ei_max = w_ei_max_bsd;
            w_ie_max = w_ie_max_bsd;
            w_ii_max = w_ii_max_bsd;
        otherwise
            assert(false);  % Dev. assert
    end
    
end
