function HpcParamsRemainderCore()

    global remoteHPC
    global distMatPVH saveIntermMat
    global ramPerNode memPerNodeLimit
    
    if distMatPVH
        saveIntermMat = false;
    end
    
    if remoteHPC
        % Limit of physical memory usage per cluster node (in megabytes).
        % The simulation will not start if the limit is exceeded.
        memPerNodeLimit = ramPerNode * 0.75;
    end
    
end