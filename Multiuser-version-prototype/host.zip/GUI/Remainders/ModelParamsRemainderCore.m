function ModelParamsRemainderCore()

    global dt t_final m_steps
    
    % The number of iterations
    m_steps = round(t_final / dt);
    
end
