function AddMeasuredParams_for_UTILITY_ComputeMaxModelSize()

    AddPanel('Measured');
    
    AddBoolScalar('gatherSCM', true, 'Show matrices of synaptic conductance at end of simulation');
    
end