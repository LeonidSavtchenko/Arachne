function AddModelAstroParams_for_UTILITY_ComputeMaxModelSize()
%% Add astrocyte network parameters

    global Astro2PyraBindings
    
    AddPanel('Model (Astro)');

    AddBoolScalar('enableAstro', false, 'Whether to enable the astrocyte network');
    
    desc = 'The type of binding of astrocytes to pyramidal cells';
    descItemPat = 'Astrocytes are bound to %s-cells and affect %s->%s release probability';
    descItems = {sprintf(descItemPat, 'e', 'e', 'e'), ...
                 sprintf(descItemPat, 'e', 'e', 'i'), ...
                 sprintf(descItemPat, 'i', 'i', 'e'), ...
                 sprintf(descItemPat, 'i', 'i', 'i')};
    AddList('astro2PyraBinding', fieldnames(Astro2PyraBindings), Astro2PyraBindings.EI, desc, descItems, 'enableAstro');
    
end
    