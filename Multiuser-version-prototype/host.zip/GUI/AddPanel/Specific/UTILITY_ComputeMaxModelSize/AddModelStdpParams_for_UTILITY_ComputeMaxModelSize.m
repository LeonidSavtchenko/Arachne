function AddModelStdpParams_for_UTILITY_ComputeMaxModelSize()
%% Add STDP-related parameters
    
    global plotStdpModelsScenarioMsg
    
    AddPanel('Model (STDP)');
    
    descPat = ['Whether to correct matrices of synaptic conductance according to Hebbian theory.<br>', ...
           	   'You can %s to plot STDP models.'];
    AddBoolScalar('enableSTDP', true, sprintf(descPat, plotStdpModelsScenarioMsg));
    
end