function scenario = GuiTypeToScenarioName(guiType)

    global GuiTypes
    
    switch guiType
        case GuiTypes.TakeOutputData
            scenario = 'take';
        case GuiTypes.StartFromScratch
            scenario = 'start';
        case GuiTypes.ContinueOldSession
            scenario = 'continue';
        case GuiTypes.MonitorBackgroundProcess
            scenario = 'monitor';
        case GuiTypes.ScriptTakeSnapshot
            scenario = 'snapshot';
        case {GuiTypes.UtilityPlotStdpModels, GuiTypes.UtilityComputeMaxModelSize}
            scenario = 'utility';
        otherwise
            error('Unknown GUI type');  % Dev. error
    end
    
end