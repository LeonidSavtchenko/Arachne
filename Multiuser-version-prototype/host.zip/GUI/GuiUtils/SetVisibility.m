function SetVisibility(h, trueFalse)
%% Set visibility property for the given handle or vector of handles

    onOff = TrueFalseToOnOff(trueFalse);
    set(h, 'Visible', onOff);
    
end
