function vis = GetVisibility(h)
    % !!?? Create OnOffToTrueFalse function for consistency with TrueFalseToOnOff
    vis = get(h, 'Visible');
    vis = strcmp(vis, 'on');
end
