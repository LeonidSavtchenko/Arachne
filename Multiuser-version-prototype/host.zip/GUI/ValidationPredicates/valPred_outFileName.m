function valid = valPred_outFileName(outFileName)

    maxLength = GetMaxFilePathNameLength() - length('.mat');
    
    valid = ~isempty(outFileName) && ...
        isempty(regexp(outFileName, '[\\/:*?"<>|]', 'once')) && ...
        length(PrepareIOFileAbsPath(outFileName)) <= maxLength;
    
end
