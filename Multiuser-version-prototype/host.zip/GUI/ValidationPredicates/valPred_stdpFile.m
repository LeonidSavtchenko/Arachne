function valid = valPred_stdpFile(stdpFile)
%% Validation predicate for "stdpFile_**" string

    absFilePath = PrepareStdpFileAbsPath(stdpFile);
    
    valid = (exist(absFilePath, 'file') == 2);
    
end
