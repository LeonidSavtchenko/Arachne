function DisablePasswordField(h)
%% !!

    assert(isa(h, 'matlab.ui.container.internal.JavaWrapper')); % Dev. assert
    
    h.JavaPeer.setEnabled(false);
    jGray = java.awt.Color(0.94, 0.94, 0.94); % !! move to palette and make sure that it is consistent with disabled edit field color
    h.JavaPeer.setBackground(jGray); % !!
    % !! make sure that the Foreground color is consistent with disabled edit field color
    
end
