function ShowConfirmationTokenMessage(success)
% !!

    title = 'Confirmation token';
    if success
        msg = {'The confirmation token was sent to your mailbox.', ...
               'Once received, please copy and paste it into the field below.', ...
               '(The token will be valid during 1 hour.)'}; % !! 1 hour is OK?
        ShowInfoMessage(msg, title);
    else
        ShowInfoMessage('The token was not sent!!', title, true);   % !! clarify the reason (pass it as an arg to this foo)
    end
    
end
