function ShowInfoMessage(msg, title,   isError)
%% !! Maybe rename and move it to better place

    if nargin == 2
        isError = false;
    end
    
    if ~isError
        icon = 'help';
    else
        icon = 'error';
    end
    
    % !! Small code dupl. with CallWithErrorHandlingPolicy (but we use msgbox instead of warndlg here)
    % !! use helpdlg (but it nonmodal)?
    h = msgbox(msg, title, icon, 'modal');
    beep();
    uiwait(h);
    
end
