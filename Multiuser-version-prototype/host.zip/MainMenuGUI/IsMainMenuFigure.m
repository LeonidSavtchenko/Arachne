function tf = IsMainMenuFigure(hf)

    % !! try to avoid this tag
    tf = ~strcmp(hf.Tag, 'secondary');
    
end
