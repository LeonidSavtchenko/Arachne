function ph = GetPanelHeight(numElems)
%% Get panel height (in pixels)
% !! not only panel, but also figure

    global mmLayout
    
    ph = mmLayout.p2by * (numElems + 2) + mmLayout.bh * numElems;
    
end
