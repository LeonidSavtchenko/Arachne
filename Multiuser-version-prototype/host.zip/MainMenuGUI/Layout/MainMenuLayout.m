function MainMenuLayout()
%% Initialize global constants for Main Menu GUI layout (all in pixels)

    global mmLayout
    
    mmLayout.pw = 310;              % Panel width
    mmLayout.bh = 30;               % Button height (!! element, not button)
    mmLayout.f2px = 20;             % Figure edge-to-panel X margin
    mmLayout.f2py = mmLayout.f2px;  % Figure edge-to-panel Y margin
    mmLayout.p2bx = 20;             % Panel edge-to-button X margin
    mmLayout.p2by = mmLayout.p2bx;  % Panel edge-to-button (!! element) Y margin
    
    mmLayout.bw = mmLayout.pw - 2 * mmLayout.p2bx;  % Button width (!! element)
    
end
