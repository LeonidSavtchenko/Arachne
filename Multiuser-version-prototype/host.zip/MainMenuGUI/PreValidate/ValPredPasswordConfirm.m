function [valid, hint] = ValPredPasswordConfirm(password1, password2)
%% Validation predicate for "Confirm Password" field

    valid = strcmp(password1, password2);
    if ~valid
        hint = 'Confirm Password (must be the same as Password)';
        %!! should be rephrased to 'Confirm New Password (must be the same as New Password)' if we confirm New Password
        return
    end
    
    hint = '';
    
end
