function [valid, hint] = ValPredToken(token)
%% Validation predicate for "Token" field
    
	expLength = 10; % !!
    
    name = 'Token';
    
    valid = (length(token) == expLength); %!!
    if ~valid
        hint = sprintf('%s (must be of length %i)', name, expLength);
        return
    end
    
    % !! check for allowed chars here
    
    hint = '';
    
end
