#pragma once

#include "Container.h"


template <typename T>
class Vector : public Container<T>
{
public:

    int length;

    Vector()
    {
        length = -1;
    }

    // TODO: Add a ctor that takes and sets length, call it from all ctors of immediate child classes

    virtual ~Vector()
    {
        length = -1;
    }
};