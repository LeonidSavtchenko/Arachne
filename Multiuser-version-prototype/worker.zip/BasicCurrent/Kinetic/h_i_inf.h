#include "BasicCurrent/BasicCurrent.h"

template <typename T>
T BasicCurrent<T>::h_i_inf(T v)
{
    T alpha_h = h_a_1 * exp(-(v + h_v_1) / h_a_2);
    T beta_h = h_b_1 / (exp(h_b_2 * (v + h_v_2)) + 1);
    return alpha_h / (alpha_h + beta_h);
}
