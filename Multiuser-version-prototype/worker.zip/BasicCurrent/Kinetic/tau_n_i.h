#include "BasicCurrent/BasicCurrent.h"

template <typename T>
T BasicCurrent<T>::tau_n_i(T v)
{
    T sum = v + n_v_1;
    T alpha_n;
    if (sum != 0)
    {
        alpha_n = n_a_1 * sum / (exp(n_a_2 * sum) - 1);
    }
    else
    {
        alpha_n = n_a_1 / n_a_2;
    }
    T beta_n = n_b_1 * exp(-(v + n_v_2) / n_b_2);
    T tau_n = 1 / (alpha_n + beta_n);
    return tau_n / phi;
}
