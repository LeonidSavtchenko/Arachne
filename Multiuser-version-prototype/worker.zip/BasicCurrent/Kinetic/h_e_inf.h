#include "BasicCurrent/BasicCurrent.h"

template <typename T>
T BasicCurrent<T>::h_e_inf(T v)
{
    T alpha_h = h_a_1 * exp(-(v + h_v_1) / h_a_2);
    T beta_h = h_b_1 / (1 + exp(-(v + h_v_2) / h_b_2));
    return alpha_h / (alpha_h + beta_h);
}
