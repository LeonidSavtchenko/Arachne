#include "BasicCurrent.h"

// Each CPP-file below contains partial implementation of BasicCurrent class
#include "BCurReadAllocateWrite.cpp"
#include "BCurDoOneStepPart1.cpp"
#include "BCurDoOneStepPart2.cpp"


// Custom constructor
template <typename T>
BasicCurrent<T>::BasicCurrent(char suffix, T dt, T basicCurrentFactor, int num)
{
    assert(suffix == 'e' || suffix == 'i');

    this->suffix = suffix;

    this->dt = dt;
    this->dt05 = dt / 2;

    this->basicCurrentFactor = basicCurrentFactor;

    ReadInputDataAllocateTemporaryArrays(num);
}


template
class BasicCurrent<float>;

template
class BasicCurrent<double>;
