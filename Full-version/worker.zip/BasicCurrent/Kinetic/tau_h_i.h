#include "BasicCurrent/BasicCurrent.h"

template <typename T>
T BasicCurrent<T>::tau_h_i(T v)
{
    T alpha_h = h_a_1 * exp(-(v + h_v_1) / h_a_2);
    T beta_h = h_b_1 / (exp(h_b_2 * (v + h_v_2)) + 1);
    T tau_h = 1 / (alpha_h + beta_h);
    return tau_h / phi;
}