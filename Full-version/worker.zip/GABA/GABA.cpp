#include "GABA.h"

// Each CPP-file below contains partial implementation of GABA class
#include "GABAReadAllocateWrite.cpp"
#include "GABADoOneStepPart1.cpp"
#include "GABADoOneStepPart2.cpp"

template <typename T>
GABA<T>::GABA()
{
    this->num_i = -1;
}

template <typename T>
GABA<T>::GABA(int num_i, int m_steps_prev, int m_steps, T dt)
{
    this->num_i = num_i;
    this->m_steps_prev = m_steps_prev;
    this->m_steps = m_steps;
    this->dt = dt;
    this->dt05 = dt / 2;
}


template
class GABA<float>;

template
class GABA<double>;
