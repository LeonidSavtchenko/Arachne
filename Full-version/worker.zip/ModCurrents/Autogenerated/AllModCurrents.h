#pragma once

#include <vector>
#include <memory>
#include <tuple>

#include "Containers/DistVector.h"
#include "MatFileIO/MatFileIOUtils.h"
#include "../AllModCurrentsBase.h"



template <typename T>
class AllModCurrents_e : public AllModCurrentsBase<T>
{
public:
    AllModCurrents_e(int num_e, bool continuationMode)
    : AllModCurrentsBase<T>(num_e)
    { }
};

template <typename T>
class AllModCurrents_i : public AllModCurrentsBase<T>
{
public:
    AllModCurrents_i(int num_i, bool continuationMode)
    : AllModCurrentsBase<T>(num_i)
    { }
};
