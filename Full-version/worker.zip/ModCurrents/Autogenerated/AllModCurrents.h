#pragma once

#include <vector>
#include <memory>
#include <tuple>

#include "Containers/DistVector.h"



// This class contains virtual methods used in case user does not import any MOD currents
template <typename T>
class AllModCurrentsBase
{
public:
    DistVector<T> I;
    
protected:
    AllModCurrentsBase(int num)
    {
        I = DistVector<T>(num);
        I.AssignZeros();
    }
    
public:
    virtual void SetVoltage(const DistVector<T> &v) { }
    
    virtual DistVector<T> GetSumCurrent()
    {
        return I;
    }
    
    virtual void DoOneStepPart1(const DistVector<T> &v, T dt05) { }
    
    virtual void DoOneStepPart2(const DistVector<T> &v, const DistVector<T> &v_tmp, T dt05) { }
    
};

template <typename T>
class AllModCurrents_e : public AllModCurrentsBase<T>
{
public:
    AllModCurrents_e(int num_e)
    : AllModCurrentsBase<T>(num_e)
    { }
};

template <typename T>
class AllModCurrents_i : public AllModCurrentsBase<T>
{
public:
    AllModCurrents_i(int num_i)
    : AllModCurrentsBase<T>(num_i)
    { }
};
