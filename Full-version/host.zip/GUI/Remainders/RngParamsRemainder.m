function RngParamsRemainder()
    
    global hostSeed
    
    rand('twister', hostSeed);
    
end