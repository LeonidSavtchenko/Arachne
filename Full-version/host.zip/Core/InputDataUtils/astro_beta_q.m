function astro_beta_q = astro_beta_q(v)
    global a2
    
    astro_beta_q = a2 .* v;