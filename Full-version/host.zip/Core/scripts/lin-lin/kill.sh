#!/bin/bash

# Kill "gs.exe" process

pkill gs.exe