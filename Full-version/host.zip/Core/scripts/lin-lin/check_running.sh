#!/bin/bash

# This SH-script determines whether at least one process with name "gs.exe" is running on this cluster

pidof gs.exe > NUL