#!/bin/bash

MATLABHOSTDIR="/home/savtchenko/amcbridge/phase9/gs/host"
WORKERDIR="/home/savtchenko/amcbridge/phase9/gs/worker"