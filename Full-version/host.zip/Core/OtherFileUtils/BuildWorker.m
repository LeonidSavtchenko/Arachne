function BuildWorker()
%% Build the worker

    global remoteHPC fakeMPI
    
    if ispc
        command = ScriptCallCommand('build_worker');
        if ~remoteHPC
            % Add one argument to the command
            command = sprintf('%s %i', command, fakeMPI);
        end
        status = system(command);
        assert(status == 0, 'Failed to build HPC kernel.');
    elseif isunix
        error('Not implemented');
    else
        error('Unknown OS');
    end
    
end