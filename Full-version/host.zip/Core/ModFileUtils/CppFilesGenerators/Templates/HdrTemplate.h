#pragma once

#include "../AtomicModCurrentBase.h"

%DEFINES

namespace mod
{

template <typename T>
%CLASS_NAME
{
public:

    %CTOR_DECLARATION

    void initBasePtrs();

    // INITIAL
    void init() override;

    // DERIVATIVE
    void states() override;

    // BREAKPOINT
    void currents() override;

private:

    // PARAMETERS
    %PARAMS

    // CONST PARAMETERS
    %CONST_PARAMS

    // STATE PARAMETERS
    %STATE_PARAMS

    // ASSIGNED PARAMETERS
    %ASSIGNED_PARAMS

    // LOCAL PARAMETERS
    %LOCAL_PARAMS

    // DERIVATIVE
    %DERIVATIVE_DECLARATION

    // PROCEDURE(S)
    %PROCEDURE_DECLARATIONS

    // FUNCTION(S)
    %FUNCTION_DECLARATIONS
};

}
