function isPresent = CheckExeExists()
%% Check if the file "gs.exe" or "gs_fakeMPI.exe" is present

    global remoteHPC fakeMPI
    
    if ispc
        if remoteHPC
            fileName = 'gs.exe';
            disp('Checking the file gs.exe on the cluster ...');
        else
            if ~fakeMPI
                fileName = 'gs.exe';
            else
                fileName = 'gs_fakeMPI.exe';
            end
            fprintf('Checking the file %s ...\n', fileName);
        end
        
        isPresent = CheckFileExists(fileName);
        
        if isPresent
            disp('Present.');
        else
            disp('Missing.');
        end
        
    elseif isunix
        error('Not implemented');
    else
        error('Unknown OS');
    end
    
end
