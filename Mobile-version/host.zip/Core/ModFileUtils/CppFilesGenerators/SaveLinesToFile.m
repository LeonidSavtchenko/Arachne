function SaveLinesToFile(lines, outDirPath, outFileName)
%%

    outFilePathName = fullfile(outDirPath, outFileName);
    
    fid = fopen(outFilePathName, 'w');
    if fid == -1
        error('Couldn''t open the next file for writing:\n%s', outFilePathName);
    end

    for i = 1 : length(lines)
        fprintf(fid, '%s\r\n', lines{i});
    end
    
    fclose(fid);
    
end