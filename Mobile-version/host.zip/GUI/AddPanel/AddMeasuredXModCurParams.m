function AddMeasuredXModCurParams() 

    AddPanel('Meas. (X/MOD-Cur)');
    
    desc = 'Array of indexes of neurons to watch extra currents in e-network.';
    AddPosIntVector('watchedExtraCurrentIdx_e', '[1]', desc, 'enableExtraCurrent_e');
    
    desc = 'Array of indexes of neurons to watch extra currents in i-network.';
    AddPosIntVector('watchedExtraCurrentIdx_i', '[1]', desc, 'enableExtraCurrent_i');
    
    desc = 'Array of indexes of neurons to watch MOD-currents in e-network.';
    AddPosIntVector('watchedModCurrentIdx_e', '[1]', desc, 'importMod_e');
    
    desc = 'Array of indexes of neurons to watch MOD-currents in i-network.';
    AddPosIntVector('watchedModCurrentIdx_i', '[1]', desc, 'importMod_i');

end