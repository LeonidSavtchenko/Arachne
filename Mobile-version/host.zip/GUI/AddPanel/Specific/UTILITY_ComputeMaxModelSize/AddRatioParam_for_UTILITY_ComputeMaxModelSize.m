function AddRatioParam_for_UTILITY_ComputeMaxModelSize()
   
    AddPanel('Ratio');
    
    AddPosRatScalar('i2eRatio', 2, '', 'The ratio "num_i / num_e"');
    
end