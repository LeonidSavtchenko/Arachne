function AddPlotXModCurParams()

    AddPanel('Plot (X/MOD-Cur)');
    
    relPred = '~startFromScratch || (enableExtraCurrent_e && ~isempty(watchedExtraCurrentIdx_e))';
    AddPlotStyleSelector('ExtraCurrent_e', 'Extra current for e-neurons', relPred);
   
    relPred = '~startFromScratch || (enableExtraCurrent_i && ~isempty(watchedExtraCurrentIdx_i))';
    AddPlotStyleSelector('ExtraCurrent_i', 'Extra current for i-neurons', relPred);
    
    relPred = '~startFromScratch || (importMod_e && ~isempty(watchedModCurrentIdx_e))';
    AddPlotStyleSelector('ModCurrent_e', 'MOD current for e-neurons', relPred);
   
    relPred = '~startFromScratch || (importMod_i && ~isempty(watchedModCurrentIdx_i))';
    AddPlotStyleSelector('ModCurrent_i', 'MOD current for i-neurons', relPred);
    
end

