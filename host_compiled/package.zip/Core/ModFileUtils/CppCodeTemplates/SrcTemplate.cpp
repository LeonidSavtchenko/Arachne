
#include <math.h>

%INCLUDE_HEADER

namespace mod
{

template <typename T>
%CTOR_SIGNATURE
{
    %INIT_CURRENTS

    %INIT_STATES

    %INIT_DERIVATIVES
}

// INITIAL
template <typename T>
%INITIAL_SIGNATURE
{
    %INITIAL_BODY
}

// DERIVATIVE
template <typename T>
%DERIVATIVE_SIGNATURE
{
    %DERIVATIVE_BODY
}

// BREAKPOINT
template <typename T>
%BREAKPOINT_SIGNATURE
{
    %BREAKPOINT_BODY
}

// PROCEDURE(S)
%PROCEDURE_DEFINITIONS

// FUNCTION(S)
%FUNCTION_DEFINITIONS

template
%TEMPLATE_INSTANTIATION_FLOAT

template
%TEMPLATE_INSTANTIATION_DOUBLE

}
